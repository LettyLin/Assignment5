package iss.java.mail;

import com.sun.mail.pop3.POP3Folder;

import javax.mail.*;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import java.io.IOException;
import java.util.Properties;

/**
 * Created by LinLi on 2015/11/15.
 */
public class MailService2014302580099 implements IMailService {


    private final transient Properties properties = System.getProperties();

    private transient MailAuthenticator2014302580099 authenticator;

    private  transient Session session;

    //URLName urlName = new URLName("POP3","pop3.163.com",995,"","linli0709@163.com","meakrxgydguqdmrl");

    private POP3Folder inbox = null;

    public void connect() throws MessagingException {
        properties.put("mail.smtp.auth","true");
        properties.put("mail.smtp.host","smtp.163.com");
        properties.put("mail.pop3.host","pop.163.com");
        properties.put("mail.store.protocol", "pop3");
        authenticator = new MailAuthenticator2014302580099("linli0709@163.com","meakrxgydguqdmrl");
        session = Session.getInstance(properties,authenticator);
    }

    @Override
    public void send(String recipient, String subject, Object content) throws MessagingException {
        final MimeMessage mimeMessage = new MimeMessage(session);

        mimeMessage.setFrom(new InternetAddress(authenticator.getUsername()));
        mimeMessage.setRecipient(Message.RecipientType.TO,new InternetAddress(recipient));
        mimeMessage.setSubject(subject);
        mimeMessage.setContent(content.toString(),"text/html;charset=utf-8");
        Transport.send(mimeMessage);
    }

    @Override
    public boolean listen() throws MessagingException {
        Store store = session.getStore();
        store.connect();

        inbox = (POP3Folder)store.getFolder("INBOX");
        inbox.open(Folder.READ_ONLY);
        FetchProfile fetchProfile = new FetchProfile();
        fetchProfile.add(UIDFolder.FetchProfileItem.UID);
        fetchProfile.add(FetchProfile.Item.ENVELOPE);
        for( Message message : inbox.getMessages()){
            if(!message.isSet(Flags.Flag.SEEN))
                return true;
        }
        return false;
    }

    @Override
    public String getReplyMessageContent(String sender, String subject) throws MessagingException, IOException {
        Store store = session.getStore();
        store.connect();

        Folder folder = store.getFolder("inbox");
        folder.open(Folder.READ_ONLY);

        Message[] messages = folder.getMessages();
        for( Message message : messages) {
            if (!message.isSet(Flags.Flag.SEEN)) {
                if (message.getSubject().equals(subject)) {
                    return message.getContent().toString();
                }
            }
        }
        folder.close(false);
        store.close();
        return null;
    }
}
